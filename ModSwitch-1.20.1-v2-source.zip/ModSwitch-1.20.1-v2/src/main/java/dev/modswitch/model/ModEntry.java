package dev.modswitch.model;

import java.nio.file.Path;
import java.util.List;

public record ModEntry(
        Path file,
        String id,
        String name,
        String version,
        boolean enabledOnDisk,
        boolean loadedThisSession,
        List<String> dependencies,
        String metadataError
) {
    public boolean valid() {
        return metadataError == null || metadataError.isBlank();
    }
}
