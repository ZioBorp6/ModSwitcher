package dev.modswitch.ui;

import dev.modswitch.model.ModEntry;
import dev.modswitch.service.ModFileService;
import dev.modswitch.service.ModScanner;
import dev.modswitch.service.RuntimeSwitchService;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ModSwitchScreen extends Screen {
    private static final int PAGE_SIZE = 6;
    private final ModScanner scanner = new ModScanner();
    private final ModFileService files = new ModFileService();
    private final RuntimeSwitchService runtime = new RuntimeSwitchService();
    private final List<ModEntry> entries = new ArrayList<>();
    private String status = "Loaded mods cannot be unloaded generically. File toggles apply next launch.";
    private int page;

    public ModSwitchScreen() {
        super(Text.literal("ModSwitch"));
    }

    @Override
    protected void init() {
        refresh();
        rebuild();
    }

    private void refresh() {
        entries.clear();
        entries.addAll(scanner.scan());
    }

    private void rebuild() {
        clearChildren();
        int start = page * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, entries.size());

        for (int i = start; i < end; i++) {
            ModEntry entry = entries.get(i);
            int row = i - start;
            int y = 58 + row * 35;
            String state = entry.enabledOnDisk() ? "ON" : "OFF";
            String label = state + "  " + entry.name() + "  [" + entry.id() + "]";
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                if (!entry.valid()) {
                    status = "Cannot toggle: " + entry.metadataError();
                    return;
                }
                if (entry.enabledOnDisk()) {
                    List<String> dependents = scanner.findEnabledDependents(entry.id());
                    if (!dependents.isEmpty()) {
                        status = "Blocked: required by " + String.join(", ", dependents);
                        return;
                    }
                }
                try {
                    var changed = files.toggleForNextLaunch(entry);
                    status = "Changed " + changed.getFileName()
                            + ". Restart Minecraft to apply. This does not unload it now.";
                    refresh();
                    page = Math.min(page, Math.max(0, (entries.size() - 1) / PAGE_SIZE));
                    rebuild();
                } catch (Exception ex) {
                    status = "File change failed: " + ex.getMessage()
                            + " Close Minecraft and change the file manually if it is locked.";
                }
            }).dimensions(width / 2 - 155, y, 310, 22).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Previous"), b -> {
            if (page > 0) { page--; rebuild(); }
        }).dimensions(width / 2 - 155, height - 48, 95, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Next"), b -> {
            if ((page + 1) * PAGE_SIZE < entries.size()) { page++; rebuild(); }
        }).dimensions(width / 2 - 55, height - 48, 95, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Refresh"), b -> {
            refresh(); page = 0; rebuild();
        }).dimensions(width / 2 + 45, height - 48, 95, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 - 45, height - 24, 90, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("JAR toggles apply after restart • O opens this screen"),
                width / 2, 31, 0xAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Page " + (page + 1) + " • " + entries.size() + " files"),
                width / 2, 44, 0x888888);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(status),
                width / 2, height - 69, 0xFFFF55);

        if (entries.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("No JAR files found in the instance mods folder."),
                    width / 2, height / 2, 0xFFFFFF);
        }

        int runtimeY = height - 83;
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Cooperative runtime integrations: " + runtime.getPlugins().size()),
                width / 2, runtimeY, 0x55FFAA);
        int index = 0;
        for (Map.Entry<String, dev.modswitch.api.ModSwitchPlugin> plugin : runtime.getPlugins().entrySet()) {
            if (index >= 2) break;
            String id = plugin.getKey();
            String label = plugin.getValue().displayName() + " (" + id + "): "
                    + (runtime.isSuspended(id) ? "suspended" : "active");
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(label),
                    width / 2, runtimeY + 11 + index * 10, 0xAAAAAA);
            index++;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
