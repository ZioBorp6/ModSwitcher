package dev.modswitch.service;

import dev.modswitch.api.ModSwitchPlugin;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;

import java.util.LinkedHashMap;
import java.util.Map;

public final class RuntimeSwitchService {
    private final Map<String, ModSwitchPlugin> plugins = new LinkedHashMap<>();
    private final Map<String, Boolean> suspended = new LinkedHashMap<>();

    public RuntimeSwitchService() {
        try {
            for (EntrypointContainer<ModSwitchPlugin> container :
                    FabricLoader.getInstance().getEntrypointContainers("modswitch", ModSwitchPlugin.class)) {
                plugins.put(container.getProvider().getMetadata().getId(), container.getEntrypoint());
                suspended.put(container.getProvider().getMetadata().getId(), false);
            }
        } catch (RuntimeException ignored) {
            // A broken optional integration must not prevent the manager opening.
        }
    }

    public Map<String, ModSwitchPlugin> getPlugins() {
        return Map.copyOf(plugins);
    }

    public boolean isSuspended(String modId) {
        return suspended.getOrDefault(modId, false);
    }

    public String toggle(String modId) {
        ModSwitchPlugin plugin = plugins.get(modId);
        if (plugin == null) return "This mod has no ModSwitch runtime integration.";
        try {
            if (isSuspended(modId)) {
                plugin.resume();
                suspended.put(modId, false);
                return "Runtime integration resumed " + modId + ".";
            }
            if (!plugin.canSuspend()) {
                return "The mod reports that it is not safe to suspend right now.";
            }
            plugin.suspend();
            suspended.put(modId, true);
            return "Runtime integration suspended " + modId + ".";
        } catch (Throwable error) {
            return "Runtime integration failed: " + error.getClass().getSimpleName()
                    + ": " + String.valueOf(error.getMessage());
        }
    }
}
