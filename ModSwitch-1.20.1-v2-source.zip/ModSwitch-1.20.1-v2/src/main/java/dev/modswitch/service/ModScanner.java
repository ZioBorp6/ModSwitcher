package dev.modswitch.service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.modswitch.model.ModEntry;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class ModScanner {
    private final Path modsDirectory = FabricLoader.getInstance().getGameDir().resolve("mods");

    public List<ModEntry> scan() {
        Set<String> loadedIds = new HashSet<>();
        for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
            loadedIds.add(mod.getMetadata().getId());
        }

        List<ModEntry> result = new ArrayList<>();
        try {
            Files.createDirectories(modsDirectory);
            try (var stream = Files.list(modsDirectory)) {
                stream.filter(Files::isRegularFile)
                        .filter(ModScanner::isModJarOrDisabled)
                        .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                        .forEach(path -> result.add(read(path, loadedIds)));
            }
        } catch (Exception e) {
            result.add(new ModEntry(modsDirectory, "scan-error", "Unable to scan mods folder",
                    "", false, false, List.of(), e.getMessage()));
        }
        return result;
    }

    private static boolean isModJarOrDisabled(Path path) {
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return name.endsWith(".jar") || name.endsWith(".jar.disabled");
    }

    private ModEntry read(Path path, Set<String> loadedIds) {
        String fileName = path.getFileName().toString();
        boolean enabled = fileName.toLowerCase(Locale.ROOT).endsWith(".jar");
        try {
            if (!enabled) {
                String original = fileName.substring(0, fileName.length() - ".disabled".length());
                Path originalPath = path.resolveSibling(original);
                if (Files.exists(originalPath)) {
                    return new ModEntry(path, "duplicate-file", fileName, "", false, false,
                            List.of(), "An enabled JAR with the same name also exists.");
                }
            }

            try (ZipFile zip = new ZipFile(path.toFile())) {
                ZipEntry metadata = zip.getEntry("fabric.mod.json");
                if (metadata == null) {
                    return new ModEntry(path, "not-fabric-mod", fileName, "", enabled, false,
                            List.of(), "No fabric.mod.json found.");
                }
                try (InputStream in = zip.getInputStream(metadata)) {
                    JsonObject json = JsonParser.parseReader(new java.io.InputStreamReader(in)).getAsJsonObject();
                    String id = string(json, "id", "unknown");
                    String version = string(json, "version", "unknown");
                    String name = string(json, "name", id);
                    List<String> dependencies = new ArrayList<>();
                    JsonElement depends = json.get("depends");
                    if (depends != null && depends.isJsonObject()) {
                        depends.getAsJsonObject().keySet().forEach(dependencies::add);
                    }
                    return new ModEntry(path, id, name, version, enabled,
                            enabled && loadedIds.contains(id), List.copyOf(dependencies), null);
                }
            }
        } catch (Exception e) {
            return new ModEntry(path, fileName, fileName, "", enabled, false,
                    List.of(), e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private static String string(JsonObject object, String key, String fallback) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonPrimitive() ? value.getAsString() : fallback;
    }

    public List<String> findEnabledDependents(String targetId) {
        List<String> dependents = new ArrayList<>();
        for (ModEntry entry : scan()) {
            if (entry.enabledOnDisk() && !entry.id().equals(targetId)
                    && entry.dependencies().contains(targetId)) {
                dependents.add(entry.name() + " (" + entry.id() + ")");
            }
        }
        return dependents;
    }
}
