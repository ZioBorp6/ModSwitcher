package dev.modswitch.service;

import dev.modswitch.model.ModEntry;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class ModFileService {
    public Path toggleForNextLaunch(ModEntry entry) throws IOException {
        String name = entry.file().getFileName().toString();
        Path target;
        if (entry.enabledOnDisk()) {
            target = entry.file().resolveSibling(name + ".disabled");
        } else if (name.toLowerCase().endsWith(".jar.disabled")) {
            target = entry.file().resolveSibling(name.substring(0, name.length() - ".disabled".length()));
        } else {
            throw new IOException("This file cannot be toggled.");
        }

        if (Files.exists(target)) {
            throw new IOException("The destination already exists: " + target.getFileName());
        }

        try {
            return Files.move(entry.file(), target, StandardCopyOption.ATOMIC_MOVE);
        } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
            return Files.move(entry.file(), target);
        }
    }
}
