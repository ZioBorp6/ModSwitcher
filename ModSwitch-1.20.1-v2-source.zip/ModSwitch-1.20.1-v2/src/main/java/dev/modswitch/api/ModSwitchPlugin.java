package dev.modswitch.api;

/**
 * Optional cooperation API for mods that want to expose a safe runtime
 * suspend/resume operation to ModSwitch.
 *
 * This is NOT JVM class unloading. Implementations must stop their own
 * callbacks/tasks and restore them safely. Mods without this entrypoint
 * can only be enabled/disabled for a later game launch.
 *
 * Register an implementation in fabric.mod.json:
 * "entrypoints": { "modswitch": ["your.package.YourModSwitchPlugin"] }
 */
public interface ModSwitchPlugin {
    /** A short label shown in the ModSwitch UI. */
    String displayName();

    /** Return true only when this mod is currently safe to suspend. */
    boolean canSuspend();

    /** Stop the mod's own activity. Must be safe to call on the client thread. */
    void suspend();

    /** Resume activity after a previous successful suspend. */
    void resume();
}
