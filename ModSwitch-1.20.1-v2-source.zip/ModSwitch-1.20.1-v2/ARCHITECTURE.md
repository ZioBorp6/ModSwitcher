# ModSwitch architecture (Fabric 1.20.1 / Java 17)

## Design goals
1. Provide a dependable mod inventory and enable/disable workflow.
2. Never claim that arbitrary JVM classes or Fabric mods can be unloaded safely.
3. Offer an opt-in runtime integration API for mods that explicitly implement their own suspend/resume lifecycle.
4. Fall back to next-launch file changes for all other mods.
5. Keep dependency checks and file changes conservative.

## Modules

- `api/ModSwitchPlugin`: optional cooperative contract. A mod may register a `modswitch` entrypoint and own its suspend/resume behavior.
- `model/ModEntry`: immutable view of one JAR, metadata, disk state and loaded state.
- `service/ModScanner`: scans the instance `mods` directory, parses `fabric.mod.json`, and compares IDs with Fabric Loader's active mod list.
- `service/ModFileService`: renames `.jar` to `.jar.disabled` or restores it. This affects the next launch, not the current in-memory mod.
- `service/RuntimeSwitchService`: discovers opt-in integrations and invokes their lifecycle callbacks.
- `ui/ModSwitchScreen`: in-game inventory and controls.
- `ModSwitchClient`: registers the configurable key binding.

## Why arbitrary live unloading is not offered
Fabric Loader discovers mods and their dependencies during startup, and mod entrypoints run during initialization. Fabric's supported transformation model uses Mixins while classes are being loaded. Once arbitrary mod classes, static state, callbacks, registries, mixins and references have been installed, a general-purpose mod cannot safely reverse all of them. JVM class redefinition is not equivalent to unloading a mod classloader and cannot generally remove structural class changes. Therefore this project does not pretend that toggling a file unloads a mod from the running game.

## Current implementation boundary
- Implemented: inventory scan, metadata parsing, loaded-state detection, dependency-aware disable guard, keybind, paginated UI, next-launch file toggle, cooperative suspend/resume API.
- Not yet implemented: Modrinth browser/downloader, recursive dependency installation, version selection, settings screen, richer dependency/version-range solver, persistent operation journal, compatibility test matrix.
- Runtime integration is cooperative only. A plugin's `suspend()` method must undo its own listeners/tasks; ModSwitch cannot undo its Mixins or registry changes.

## Planned phases
1. Build and test on Fabric 1.20.1, Java 17.
2. Add persistent settings and search/filter UI.
3. Add Modrinth project/version browser with loader + game-version filters.
4. Add dependency graph and transactional installer with backup/rollback.
5. Publish the optional integration API for participating mods.
6. Expand runtime integrations only where an individual mod has a safe lifecycle contract.

## Safety
Back up the instance before changing mod files. Do not disable Fabric Loader, Fabric API, or a dependency required by another enabled mod. Always restart after file toggles. A file rename may fail on operating systems that lock loaded JARs; close the game and retry.
