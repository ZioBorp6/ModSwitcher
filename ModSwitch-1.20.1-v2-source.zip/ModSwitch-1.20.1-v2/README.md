# ModSwitch 2.0.0-alpha.1

Independent Fabric mod manager targeting Minecraft **1.20.1** and **Java 17**.

## Included in this source milestone
- In-game GUI opened with **O** (rebindable under Controls).
- Scans `.jar` and `.jar.disabled` files in the active instance's `mods` folder.
- Reads `fabric.mod.json` mod ID, name, version and declared dependencies.
- Detects which scanned mods are loaded in the current session.
- Blocks disabling a mod when another enabled JAR declares it as a dependency.
- Enables/disables JARs for the **next launch**.
- Optional cooperative runtime suspend/resume entrypoint API.

## Honest live-switching limitation
This is not arbitrary live unloading. A normal Fabric mod cannot safely remove another mod's loaded classes, Mixins, static state, event registrations and registry changes from the running JVM. Mods without an explicit `modswitch` integration can only be toggled for the next launch. See [ARCHITECTURE.md](ARCHITECTURE.md).

## Build
Use JDK 17 and Gradle 8.7 or a compatible Gradle installation:

```bash
gradle build
```

Output: `build/libs/modswitch-2.0.0-alpha.1.jar`

Install the remapped JAR in the Fabric 1.20.1 instance's `mods` folder. Back up the instance first.

## Build workflow
A GitHub Actions workflow is included at `.github/workflows/build.yml`.
